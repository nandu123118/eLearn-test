<?php
$cn=mysql_connect("localhost","root","") or die("Could not Connect My Sql");
mysql_select_db("quiz",$cn)  or die("Could connect to Database");
?>
